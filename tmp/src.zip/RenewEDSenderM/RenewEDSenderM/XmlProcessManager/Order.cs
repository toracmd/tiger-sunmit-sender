﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RenewEDSenderM.XmlProcessManager
{
    class Order
    {
        public string sequence = "";
        public string result="";
        public string time="";
        public string heart_result="";
        public string beginTime="";
        public string endTime ="";
        public string period ="";
        public string keytype ="";
        public string key ="";
        public string order="";
    } 
}
